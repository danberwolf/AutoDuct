/* 
 * File:   BTComCallbacksApp.h
 * Author: danie
 *
 * Created on 16. Juli 2022, 23:20
 */

#ifndef BTCOMCALLBACKSBOOTLOADER_H
#define	BTCOMCALLBACKSBOOTLOADER_H


#include "BTCom.h"
#include "UART1.h"


void BTCom_SetupCallbacks();


#endif	/* BTCOMCALLBACKSAPP_H */

