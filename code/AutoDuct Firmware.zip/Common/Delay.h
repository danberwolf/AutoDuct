#ifndef _DELAY_H_
#define _DELAY_H_

#include "HardwareProfile.h"
#include <plib.h>

void Delay10us(DWORD dwCount);
void Delayms(WORD wCount);


#endif
